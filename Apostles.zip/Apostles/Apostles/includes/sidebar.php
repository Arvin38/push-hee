<div class="sidebar">
    <div class="text-center p-3 border-bottom">
        <h4 class="text-primary fw-bold mb-0 d-flex align-items-center justify-content-center">
            <img src="https://scontent.fcgy2-1.fna.fbcdn.net/v/t1.15752-9/483156597_1546510726032748_1316544022612528289_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=0024fc&_nc_eui2=AeE0mLOypOfzwWwCqiq-GyjUC9yXFe75T9EL3JcV7vlP0TrFvIUFwlyJ2POnxQwi40iL-ykX1FiIH0-isnAz8M-a&_nc_ohc=ahqzs3ASFKQQ7kNvwGmY5qz&_nc_oc=Adnbh6wi7aXgnwaDFP9RvZLnrHqPM2oRG3ByzfzABXtFoM7Vtiw4RQ_UPHvKGmWkz1I&_nc_ad=z-m&_nc_cid=0&_nc_zt=23&_nc_ht=scontent.fcgy2-1.fna&oh=03_Q7cD2QHf55bh2TGAvFW74YNs8j4hLb8wUmrA7gdv4_pQX9u7uw&oe=6852A29B" alt="APOSTLE" height="30" class="me-2"> APOSTLE
        </h4>
    </div>
    <div class="sidebar-menu mt-4">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'bg-primary text-white' : 'bg-light text-primary'; ?>">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        Dashboard
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="inventory.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-box"></i>
                        </div>
                        Inventory
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="reports.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        Reports
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="suppliers.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'suppliers.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-users"></i>
                        </div>
                        Suppliers
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="orders.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        Orders
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="manage_store.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_store.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'manage_store.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-store"></i>
                        </div>
                        Manage Store
                    </div>
                </a>
            </li>
            <li class="nav-item mt-4">
                <a href="settings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'bg-primary text-white' : 'bg-light text-dark'; ?>">
                            <i class="fas fa-cog"></i>
                        </div>
                        Settings
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a href="logout.php" class="nav-link">
                    <div class="d-flex align-items-center">
                        <div class="circle-icon me-3 bg-light text-dark">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                        Log Out
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>
