<?php
/**
 * Unit Test Runner for Inventory Management System
 * 
 * This script will run all tests in the tests/ directory
 */

// Check if PHPUnit is installed
if (!file_exists('vendor/bin/phpunit')) {
    echo "PHPUnit not found. Please make sure you've installed PHPUnit via Composer.\n";
    exit(1);
}

// Run the tests
echo "Running inventory management system tests...\n";
passthru('./vendor/bin/phpunit --colors=always');