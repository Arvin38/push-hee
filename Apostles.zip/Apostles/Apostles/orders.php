<?php
session_start();
require_once 'config.php';
require_once 'data.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get orders data (mock data for demonstration)
$orders = [
    [
        'id' => 'ORD-001',
        'customer' => 'John Smith',
        'date' => '2025-05-10',
        'items' => 5,
        'total' => 245.50,
        'status' => '',
        'payment' => ''
    ],
    [
        'id' => 'ORD-002',
        'customer' => 'Emma Johnson',
        'date' => '2025-05-12',
        'items' => 3,
        'total' => 120.75,
        'status' => '',
        'payment' => ''
    ],
    [
        'id' => 'ORD-003',
        'customer' => 'Michael Brown',
        'date' => '2025-05-13',
        'items' => 2,
        'total' => 85.25,
        'status' => '',
        'payment' => ''
    ],
    [
        'id' => 'ORD-004',
        'customer' => 'Sarah Davis',
        'date' => '2025-05-15',
        'items' => 7,
        'total' => 340.00,
        'status' => '',
        'payment' => ''
    ],
    [
        'id' => 'ORD-005',
        'customer' => 'Robert Wilson',
        'date' => '2025-05-16',
        'items' => 1,
        'total' => 45.99,
        'status' => '',
        'payment' => ''
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Inventory Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Orders</h2>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addOrderModal">
                        <i class="fas fa-plus"></i> New Order
                    </button>
                </div>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Order Management</h5>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex">
                                <div class="input-group me-2" style="width: 300px;">
                                    <span class="input-group-text bg-white border-end-0">
                                        <i class="fas fa-search text-muted"></i>
                                    </span>
                                    <input type="text" class="form-control border-start-0" placeholder="Search orders...">
                                </div>
                                <button class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#scanBarcodeModal">
                                    <i class="fas fa-barcode"></i> Scan Barcode
                                </button>
                            </div>
                            <div class="d-flex">
                                <div class="dropdown me-2">
                                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-filter"></i> Filter
                                    
                                </div>
                                <button class="btn btn-outline-secondary">
                                    <i class="fas fa-download"></i> Export
                                </button>
                            </div>
                        </div>
                        
                        <div class="table-responsive mt-3">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Date</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><a href="#" class="text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#viewOrderModal" data-id="<?php echo $order['id']; ?>"><?php echo $order['id']; ?></a></td>
                                        <td><?php echo $order['customer']; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($order['date'])); ?></td>
                                        <td><?php echo $order['items']; ?></td>
                                        <td>$<?php echo number_format($order['total'], 2); ?></td>
                                        <td>
                                            <?php 

                                            
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?>"><?php echo $order['status']; ?></span>
                                        </td>
                                        <td><?php echo $order['payment']; ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewOrderModal" data-id="<?php echo $order['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="#" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editOrderModal" data-id="<?php echo $order['id']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteOrderModal" data-id="<?php echo $order['id']; ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <!-- View Order Modal -->
    <div class="modal fade" id="viewOrderModal" tabindex="-1" aria-labelledby="viewOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewOrderModalLabel">Order Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Order Information</h6>
                            <p><strong>Order ID:</strong> <span id="orderIdDetail">ORD-001</span></p>
                            <p><strong>Date:</strong> <span id="orderDateDetail">May 10, 2025</span></p>
                            <p><strong>Status:</strong> <span id="orderStatusDetail" class="badge bg-success">Completed</span></p>
                            <p><strong>Payment Method:</strong> <span id="orderPaymentDetail">Credit Card</span></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Customer Information</h6>
                            <p><strong>Name:</strong> <span id="customerNameDetail">John Smith</span></p>
                            <p><strong>Email:</strong> <span id="customerEmailDetail">john.smith@example.com</span></p>
                            <p><strong>Phone:</strong> <span id="customerPhoneDetail">(555) 123-4567</span></p>
                            <p><strong>Address:</strong> <span id="customerAddressDetail">123 Main St, Anytown, USA</span></p>
                        </div>
                    </div>
                    
                    <h6>Order Items</h6>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Coffee Beans</td>
                                    <td>$15.99</td>
                                    <td>2</td>
                                    <td>$31.98</td>
                                </tr>
                                <tr>
                                    <td>Rice</td>
                                    <td>$20.50</td>
                                    <td>3</td>
                                    <td>$61.50</td>
                                </tr>
                                <tr>
                                    <td>Tea</td>
                                    <td>$12.50</td>
                                    <td>1</td>
                                    <td>$12.50</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                                    <td>$105.98</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Tax (15%):</strong></td>
                                    <td>$15.90</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Shipping:</strong></td>
                                    <td>$5.00</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                    <td><strong>$126.88</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.print()">Print</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scan Barcode Modal -->
    <div class="modal fade" id="scanBarcodeModal" tabindex="-1" aria-labelledby="scanBarcodeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="scanBarcodeModalLabel">Scan Barcode</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <div id="scanner-container" class="mb-3">
                            <video id="scanner" style="width: 100%; max-height: 300px; border: 1px solid #ddd; border-radius: 4px;"></video>
                        </div>
                        <button id="start-scanner" class="btn btn-primary">
                            <i class="fas fa-camera"></i> Start Scanner
                        </button>
                        <button id="stop-scanner" class="btn btn-secondary d-none">
                            <i class="fas fa-stop"></i> Stop Scanner
                        </button>
                    </div>
                    <div class="mb-3">
                        <label for="barcode-input" class="form-label">Or enter barcode manually:</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                            <input type="text" class="form-control" id="barcode-input" placeholder="Enter barcode...">
                            <button class="btn btn-outline-primary" type="button">Search</button>
                        </div>
                    </div>
                    <div id="scan-result" class="alert alert-info d-none">
                        <span id="scan-result-text"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@ericblade/quagga2/dist/quagga.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Barcode scanner functionality
        const startScannerBtn = document.getElementById('start-scanner');
        const stopScannerBtn = document.getElementById('stop-scanner');
        const scanResult = document.getElementById('scan-result');
        const scanResultText = document.getElementById('scan-result-text');
        
        let scannerRunning = false;
        
        if (startScannerBtn) {
            startScannerBtn.addEventListener('click', function() {
                if (typeof Quagga !== 'undefined') {
                    initBarcodeScanner();
                    startScannerBtn.classList.add('d-none');
                    stopScannerBtn.classList.remove('d-none');
                } else {
                    alert('Barcode scanner library not loaded. Please try again later.');
                }
            });
        }
        
        if (stopScannerBtn) {
            stopScannerBtn.addEventListener('click', function() {
                if (scannerRunning) {
                    Quagga.stop();
                    scannerRunning = false;
                }
                startScannerBtn.classList.remove('d-none');
                stopScannerBtn.classList.add('d-none');
            });
        }
        
        function initBarcodeScanner() {
            Quagga.init({
                inputStream: {
                    name: "Live",
                    type: "LiveStream",
                    target: document.querySelector('#scanner'),
                    constraints: {
                        width: 640,
                        height: 480,
                        facingMode: "environment"
                    },
                },
                decoder: {
                    readers: [
                        "code_128_reader",
                        "ean_reader",
                        "ean_8_reader",
                        "code_39_reader",
                        "code_39_vin_reader",
                        "codabar_reader",
                        "upc_reader",
                        "upc_e_reader",
                        "i2of5_reader"
                    ],
                    debug: {
                        showCanvas: true,
                        showPatches: true,
                        showFoundPatches: true,
                        showSkeleton: true,
                        showLabels: true,
                        showPatchLabels: true,
                        showRemainingPatchLabels: true,
                        boxFromPatches: {
                            showTransformed: true,
                            showTransformedBox: true,
                            showBB: true
                        }
                    }
                },
            }, function(err) {
                if (err) {
                    console.error(err);
                    alert('Error initializing the barcode scanner: ' + err);
                    return;
                }
                scannerRunning = true;
                Quagga.start();
            });
            
            Quagga.onDetected(function(result) {
                if (result && result.codeResult && result.codeResult.code) {
                    const code = result.codeResult.code;
                    scanResultText.textContent = 'Barcode detected: ' + code;
                    scanResult.classList.remove('d-none');
                    scanResult.classList.remove('alert-danger');
                    scanResult.classList.add('alert-success');
                    
                    // Here you would typically search for the product with this barcode
                    // For demo, we'll just display the code
                    
                    // Optionally stop scanner after successful scan
                    // Quagga.stop();
                }
            });
            
            Quagga.onProcessed(function(result) {
                const drawingCtx = Quagga.canvas.ctx.overlay;
                const drawingCanvas = Quagga.canvas.dom.overlay;
                
                if (result) {
                    if (result.boxes) {
                        drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                        result.boxes.filter(function(box) {
                            return box !== result.box;
                        }).forEach(function(box) {
                            Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: "green", lineWidth: 2 });
                        });
                    }
                    
                    if (result.box) {
                        Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: "#00F", lineWidth: 2 });
                    }
                    
                    if (result.codeResult && result.codeResult.code) {
                        Quagga.ImageDebug.drawPath(result.line, { x: 'x', y: 'y' }, drawingCtx, { color: 'red', lineWidth: 3 });
                    }
                }
            });
        }
        
        // Order modals functionality
        const viewOrderModal = document.getElementById('viewOrderModal');
        if (viewOrderModal) {
            viewOrderModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const orderId = button.getAttribute('data-id');
                
                // In a real app, fetch order details via AJAX
                // For demo, we'll use hardcoded data
                document.getElementById('orderIdDetail').textContent = orderId;
            });
        }
    });
    </script>
</body>
</html>