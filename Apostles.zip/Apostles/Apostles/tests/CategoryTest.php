<?php
use PHPUnit\Framework\TestCase;

class CategoryTest extends TestCase
{
    /**
     * Test that only allowed product categories are used
     */
    public function testAllowedCategoriesOnly()
    {
        // Define the allowed categories
        $allowedCategories = ['Grains', 'Oil', 'Pasta', 'Beverages', 'Canned Goods'];
        
        // Test category that should be allowed
        $categoryToTest = 'Beverages';
        $this->assertTrue(in_array($categoryToTest, $allowedCategories));
        
        // Test category that should not be allowed
        $invalidCategory = 'Electronics';
        $this->assertFalse(in_array($invalidCategory, $allowedCategories));
    }
    
    /**
     * Test category filter functionality
     */
    public function testCategoryFiltering()
    {
        // Create a sample list of products
        $products = [
            ['name' => 'Creamy Latte Nescafe', 'category' => 'Beverages'],
            ['name' => 'Tuna', 'category' => 'Canned Goods'],
            ['name' => 'Del monte spaghetti', 'category' => 'Pasta'],
            ['name' => 'Bottled Water' => 'Beverages'],
            ['name' => 'Iced Tea', 'category' => 'Beverages'],
        ];
        
        // Filter for Canned Goods
        $filteredProducts = array_filter($products, function($product) {
            return $product['category'] === 'Canned Goods';
        });
        
        // Assertions
        $this->assertCount(2, $filteredProducts);
        $productNames = array_map(function($product) { 
            return $product['name']; 
        }, array_values($filteredProducts));
        
        $this->assertTrue(in_array('Tuna', $productNames));
        $this->assertTrue(in_array('Beans', $productNames));
    }
    
    /**
     * Test category count calculation
     */
    public function testCategoryCountCalculation()
    {
        // Create a sample list of products
        $products = [
            ['name' => 'Rice', 'category' => 'Grains'],
            ['name' => 'Wheat', 'category' => 'Grains'],
            ['name' => 'Olive Oil', 'category' => 'Oil'],
            ['name' => 'Spaghetti', 'category' => 'Pasta'],
            ['name' => 'Coffee', 'category' => 'Beverages'],
            ['name' => 'Tea', 'category' => 'Beverages'],
            ['name' => 'Tuna', 'category' => 'Canned Goods'],
            ['name' => 'Beans', 'category' => 'Canned Goods']
        ];
        
        // Count products by category
        $categoryCounts = [];
        foreach ($products as $product) {
            $category = $product['category'];
            if (!isset($categoryCounts[$category])) {
                $categoryCounts[$category] = 0;
            }
            $categoryCounts[$category]++;
        }
        
        // Assertions
        $this->assertEquals(2, $categoryCounts['Grains']);
        $this->assertEquals(1, $categoryCounts['Oil']);
        $this->assertEquals(1, $categoryCounts['Pasta']);
        $this->assertEquals(2, $categoryCounts['Beverages']);
        $this->assertEquals(2, $categoryCounts['Canned Goods']);
    }
}